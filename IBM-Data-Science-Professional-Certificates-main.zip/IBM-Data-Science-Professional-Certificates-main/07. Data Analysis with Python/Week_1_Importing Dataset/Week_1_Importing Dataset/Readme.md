# Week_1
## Importing Dataset ✨

## 🔑 Key Skills Learned

1. Defining the Business Problem: Look at the data and make some high-level decision on what kind of analysis should be done

2. Importing and Exporting Data in Python: How to import data from multiple data sources using the Pandas library and how to export files into different formats.

3. Analyzing Data in Python: How to do some introductory analysis in Python using functions:👇 

- info(): to view the column names and data types.
- df.head(): to view the first few lines of the dataset.
- df.columns:to view colomns dataset
- df.describe(): to describe and summarize the dataset.
