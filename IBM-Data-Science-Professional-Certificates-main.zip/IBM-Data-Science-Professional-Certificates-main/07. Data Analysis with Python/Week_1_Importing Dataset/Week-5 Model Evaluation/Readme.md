# Week-5 Model Evaluation
## Learning Objectives
- Describe data model refinement techniques
- Explain overfitting, underfitting and model selection
- Apply ridge regression to regularize and reduce the standard errors to avoid overfitting a regression model
- Apply grid search techniques to Python data
