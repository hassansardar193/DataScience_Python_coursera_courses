# 📅 Week-1
## Introduction to Data Visualization Tools
### 🔑 Key Skills Learned
- Writing Python code to manipulate data in a Pandas data frame
- Converting a JSON file into a Create a Python Pandas data frame by converting a JSON file
- Creating a Jupyter notebook and make it sharable using GitHub
- Using data science methodologies to define and formulate a real-world business problem.
- Using data analysis tools to load a dataset, clean it, and find out interesting insights from it.
#### This repository contains quiz and lab
