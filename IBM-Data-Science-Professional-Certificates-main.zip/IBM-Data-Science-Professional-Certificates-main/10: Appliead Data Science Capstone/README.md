# Applied Data Science Capstone✨
## 📑 Course Syllabus
## [📅 Week-1](https://github.com/DerartuDagne/IBM-Data-Science-Professional-Certificates/tree/main/10:%20Appliead%20Data%20Science%20Capstone/Week_1_Introduction)

###  Introduction to Capstone Project

- Capstone Introduction and Understanding the Datasets

- Collecting the Data

- DataWrangling

- Quiz

## [📅 Week-2](https://github.com/DerartuDagne/IBM-Data-Science-Professional-Certificates/tree/main/10:%20Appliead%20Data%20Science%20Capstone/Week_2_Exploratory%20Data%20Analysis)

### Exploratory Data Analysis

- Exploratory Analysis Using SQL

- Exploratory Analysis Using Pandas and Matplotlib

- Check Points

- Quiz

## [📅 Week-3](https://github.com/DerartuDagne/IBM-Data-Science-Professional-Certificates/tree/main/10:%20Appliead%20Data%20Science%20Capstone/Week_3_Interactive%20Visual%20Analytics%20and%20Dashboards) 

### Interactive Visual Analytics and Dashboard

- Quiz

 
## [📅 Week-4](https://github.com/DerartuDagne/IBM-Data-Science-Professional-Certificates/tree/main/10:%20Appliead%20Data%20Science%20Capstone/Week_4_Predictive_Analysis)

## Predictive Analysis (Classification)

- Quiz

## 📅 Week_5 

### Present Your Findings

- How to Present Your Findings
- Final Presentation

