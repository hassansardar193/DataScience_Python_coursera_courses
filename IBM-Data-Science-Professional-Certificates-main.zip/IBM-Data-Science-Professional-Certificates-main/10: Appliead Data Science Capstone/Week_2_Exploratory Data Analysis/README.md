# 📅 Week_2
## Exploratory Analysis Using SQL
### 🔑 Key Skills Learned
- Creating scatter plots and bar charts by writing Python code to analyze data in a Pandas data frame
- Writing Python code to conduct exploratory data analysis by manipulating data in a Pandas data frame
- Writing and execute SQL queries to select and sort data
- Using data visualization skills to visualize the data and extract meaningful patterns to guide the modeling process.
