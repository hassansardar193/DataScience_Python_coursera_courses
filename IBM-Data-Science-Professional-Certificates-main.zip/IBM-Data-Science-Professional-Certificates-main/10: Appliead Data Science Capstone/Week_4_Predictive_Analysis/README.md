# 📅 Week-4
## Predictive Analysis (Classification)

### 🔑 Key Skills Learned
- Spliting the data into training testing data.
- Training different classification models.
- Hyperparameter grid search.
- Using machine learning skills to build a predictive model to help a business function more efficiently.
##### Quiz and Lab 
