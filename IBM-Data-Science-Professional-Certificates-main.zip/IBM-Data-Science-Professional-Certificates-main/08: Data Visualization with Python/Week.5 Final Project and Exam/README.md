# Final Project and Exam👊 

The goal of the projectis to analyze the performance of the reporting airline to improve fight reliability thereby improving customer reliability. 

## 🔑Key Concepts

- Practicing data analyst skills learned in this course in the final lab assignment.
- Submitting the final lab assignment for peer review.
- Reviewing assignments submitted by our peers.
