# Basic and Specialized Visualization Tools✨

## 🔑 Key Concepts

Create with Matplotlib

- Area plots
- Histograms
- Bar charts
- Pie charts
- Box plots
- Scatter plots
- Bubble plots
